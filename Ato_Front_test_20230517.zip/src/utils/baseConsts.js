const baseDomain = "ato-auto-estimate.107.jp"
const orikomiDomain = "orikomi-quote-api.107.jp"
const paymentDomain      =  "ato-payment-api.107.jp"

export {
    baseDomain,
    orikomiDomain,
    paymentDomain
}