<template>

</template>

<script>
export default {
  name: "TrackingInfoRegisterDialog.vue"
}
</script>

<style scoped>

</style>