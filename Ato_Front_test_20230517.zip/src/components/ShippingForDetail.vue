<template>

</template>

<script>
import {BIconCircleFill, BIconPlusSquareFill,BIconCheck2Square, BIconX, BIconXCircleFill, BIconXSquare} from "../../node_modules/bootstrap-icons-vue"
export default {
  name: "ShippingForDetail.vue"
}
</script>

<style scoped>

</style>